def file_in_temp_dir(directory: str, file_name: str):
    return "/".join([directory, file_name])
